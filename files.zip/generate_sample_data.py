#!/usr/bin/env python3
"""
Sample Data Generator for Testing

Creates realistic sample data that mimics Indiana Gateway format
so you can test the parser and Mark integration before downloading real data.

Usage:
    python generate_sample_data.py --municipalities 20 --output ./gateway_data/raw/
"""

import pandas as pd
import random
from pathlib import Path
import argparse

class SampleDataGenerator:
    """Generate realistic sample municipality benefits data"""
    
    # Real Indiana municipalities of various sizes
    MUNICIPALITIES = [
        ("Indianapolis", 514),
        ("Fort Wayne", 380),
        ("Evansville", 290),
        ("South Bend", 245),
        ("Carmel", 220),
        ("Fishers", 195),
        ("Bloomington", 180),
        ("Hammond", 165),
        ("Gary", 150),
        ("Muncie", 135),
        ("Lafayette", 125),
        ("Terre Haute", 120),
        ("Kokomo", 110),
        ("Anderson", 105),
        ("Noblesville", 95),
        ("Greenwood", 85),
        ("Elkhart", 80),
        ("Mishawaka", 75),
        ("Lawrence", 70),
        ("Jeffersonville", 65),
        ("Columbus", 60),
        ("Portage", 55),
        ("Westfield", 50),
        ("Valparaiso", 48),
        ("Goshen", 45)
    ]
    
    # Benefit categories with typical cost ranges (monthly per employee)
    BENEFIT_TYPES = {
        "Health Insurance - Medical": (450, 650),
        "Health Insurance - Prescription": (80, 120),
        "Dental Insurance": (35, 55),
        "Vision Insurance": (8, 15),
        "Life Insurance - Basic": (10, 20),
        "Life Insurance - Supplemental": (5, 12),
        "Long Term Disability": (15, 25),
        "Short Term Disability": (8, 15),
        "PERF - Retirement": (100, 150),
        "Social Security - Employer": (45, 75),
        "Medicare - Employer": (10, 18),
        "Workers Compensation": (25, 45),
        "Unemployment Insurance": (5, 12),
        "Employee Assistance Program": (3, 8),
        "Wellness Program": (5, 15),
        "Flexible Spending Admin": (2, 5)
    }
    
    DEPARTMENTS = [
        "Mayor's Office",
        "Police Department", 
        "Fire Department",
        "Public Works",
        "Parks and Recreation",
        "Human Resources",
        "Finance",
        "Legal",
        "Planning and Zoning",
        "Building and Safety",
        "Information Technology",
        "Utilities"
    ]
    
    FUNDS = [
        "General Fund",
        "Parks Fund",
        "Police Fund",
        "Fire Fund",
        "Street Fund"
    ]
    
    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def generate_municipality_data(self, name: str, employees: int, year: int = 2024) -> pd.DataFrame:
        """Generate benefit disbursement data for one municipality"""
        
        rows = []
        
        # Add some variance (some cities pay more/less)
        cost_multiplier = random.uniform(0.85, 1.15)
        
        for dept in self.DEPARTMENTS:
            # Not all depts in all cities
            if random.random() > 0.7:
                continue
            
            dept_employees = int(employees * random.uniform(0.05, 0.15))
            
            for fund in random.sample(self.FUNDS, k=random.randint(1, 2)):
                
                for benefit_name, (min_cost, max_cost) in self.BENEFIT_TYPES.items():
                    
                    # Not all benefits in all departments
                    if random.random() > 0.8:
                        continue
                    
                    # Calculate monthly per employee cost
                    monthly_per_emp = random.uniform(min_cost, max_cost) * cost_multiplier
                    
                    # Annual total for this benefit in this department
                    annual_total = monthly_per_emp * 12 * dept_employees
                    
                    # Add some noise
                    annual_total *= random.uniform(0.95, 1.05)
                    
                    rows.append({
                        'UnitName': name,
                        'Year': year,
                        'FundName': fund,
                        'DepartmentName': dept,
                        'AccountCode': '1200',  # Employee benefits code
                        'AccountDescription': benefit_name,
                        'Amount': round(annual_total, 2)
                    })
        
        return pd.DataFrame(rows)
    
    def generate_dataset(self, num_municipalities: int = 20, year: int = 2024) -> pd.DataFrame:
        """Generate complete dataset with multiple municipalities"""
        
        print(f"\nGenerating sample data for {num_municipalities} municipalities...")
        
        all_data = []
        
        municipalities = random.sample(self.MUNICIPALITIES, min(num_municipalities, len(self.MUNICIPALITIES)))
        
        for name, employees in municipalities:
            print(f"  Generating: {name} ({employees} employees)")
            muni_data = self.generate_municipality_data(name, employees, year)
            all_data.append(muni_data)
        
        combined = pd.concat(all_data, ignore_index=True)
        
        print(f"\n✓ Generated {len(combined)} line items")
        
        return combined
    
    def save_as_gateway_format(self, df: pd.DataFrame, filename: str = "sample_disbursements_2024.txt"):
        """Save in pipe-delimited format like real Gateway files"""
        
        output_path = self.output_dir / filename
        
        # Save with pipe delimiter
        df.to_csv(output_path, sep='|', index=False)
        
        print(f"✓ Saved to: {output_path}")
        print(f"  Format: pipe-delimited (.txt)")
        print(f"  Rows: {len(df):,}")
        print(f"  Columns: {len(df.columns)}")
        
        return output_path
    
    def generate_summary(self, df: pd.DataFrame):
        """Print summary statistics of generated data"""
        
        print("\n" + "=" * 70)
        print("SAMPLE DATA SUMMARY")
        print("=" * 70)
        
        # Total by municipality
        muni_totals = df.groupby('UnitName')['Amount'].sum().sort_values(ascending=False)
        
        print("\nTotal Benefits by Municipality:")
        print("-" * 70)
        for name, total in muni_totals.head(10).items():
            # Get employee count
            emp_count = next(emp for n, emp in self.MUNICIPALITIES if n == name)
            monthly_per_emp = (total / emp_count / 12)
            print(f"  {name:25} ${total:>12,.0f}  |  ${monthly_per_emp:>6,.0f}/emp/mo")
        
        # Overall statistics
        print("\n" + "=" * 70)
        
        # Calculate per-employee costs
        muni_employees = {name: emp for name, emp in self.MUNICIPALITIES}
        
        per_emp_costs = []
        for name, total in muni_totals.items():
            if name in muni_employees:
                emp_count = muni_employees[name]
                monthly_per_emp = (total / emp_count / 12)
                per_emp_costs.append(monthly_per_emp)
        
        per_emp_series = pd.Series(per_emp_costs)
        
        print("Per-Employee Monthly Costs:")
        print("-" * 70)
        print(f"  Minimum:         ${per_emp_series.min():.2f}")
        print(f"  25th Percentile: ${per_emp_series.quantile(0.25):.2f}")
        print(f"  Median:          ${per_emp_series.median():.2f}")
        print(f"  75th Percentile: ${per_emp_series.quantile(0.75):.2f}")
        print(f"  90th Percentile: ${per_emp_series.quantile(0.90):.2f}")
        print(f"  Maximum:         ${per_emp_series.max():.2f}")
        print(f"  Mean:            ${per_emp_series.mean():.2f}")
        print()

def main():
    parser = argparse.ArgumentParser(description='Generate sample Gateway data for testing')
    parser.add_argument('--municipalities', type=int, default=20, help='Number of municipalities')
    parser.add_argument('--output', default='./gateway_data/raw', help='Output directory')
    parser.add_argument('--year', type=int, default=2024, help='Data year')
    
    args = parser.parse_args()
    
    print("\n" + "=" * 70)
    print("SAMPLE DATA GENERATOR")
    print("=" * 70)
    print("\nThis generates realistic sample data that mimics Indiana Gateway format.")
    print("Use this to test the parser and Mark integration before downloading real data.")
    
    generator = SampleDataGenerator(args.output)
    
    # Generate data
    df = generator.generate_dataset(args.municipalities, args.year)
    
    # Save
    output_file = generator.save_as_gateway_format(df, f"sample_disbursements_{args.year}.txt")
    
    # Show summary
    generator.generate_summary(df)
    
    print("=" * 70)
    print("NEXT STEPS")
    print("=" * 70)
    print("\n1. Test the parser:")
    print(f"   python gateway_parser.py --input {args.output} --output ./gateway_data/parsed")
    print("\n2. Review the output:")
    print("   cat ./gateway_data/parsed/gateway_benchmark_data.json | jq")
    print("\n3. Feed to Mark and test queries:")
    print('   - "What do cities our size typically pay?"')
    print('   - "How does $1,050/month compare to benchmarks?"')
    print("\n4. Once satisfied, download real data from Gateway")
    print()

if __name__ == "__main__":
    main()
