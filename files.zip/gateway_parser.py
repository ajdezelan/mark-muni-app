#!/usr/bin/env python3
"""
Indiana Gateway File Parser

Parses downloaded pipe-delimited files from Indiana Gateway
and extracts benefits benchmarking data for Mark.

Usage:
    python gateway_parser.py --input raw_files/ --output parsed/
"""

import pandas as pd
import json
from pathlib import Path
from typing import Dict, List, Tuple
import re
from collections import defaultdict

class GatewayFileParser:
    """Parse downloaded Indiana Gateway data files"""
    
    # Benefits-related keywords to search for
    BENEFITS_KEYWORDS = [
        'health insurance', 'medical insurance', 'health benefit',
        'dental insurance', 'vision insurance', 'vision care',
        'life insurance', 'disability insurance',
        'employee benefit', 'fringe benefit',
        'PERF', 'retirement', 'pension',
        'wellness', 'EAP', 'employee assistance',
        'flexible spending', 'FSA', 'HSA',
        'workers comp', 'unemployment insurance',
        'social security', 'medicare'
    ]
    
    # Line item codes that typically contain benefits (vary by municipality)
    BENEFITS_ACCOUNT_CODES = [
        '1200', '1210', '1220', '1230',  # Common benefits codes
        '6200', '6210', '6220'  # Alternative coding systems
    ]
    
    def __init__(self, input_dir: Path, output_dir: Path):
        self.input_dir = Path(input_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.municipalities = defaultdict(lambda: {
            'name': '',
            'years': {},
            'total_benefits': 0,
            'avg_monthly_per_employee': 0
        })
    
    def load_file(self, filepath: Path) -> pd.DataFrame:
        """Load a pipe-delimited Gateway file"""
        
        print(f"Loading: {filepath.name}")
        
        try:
            # Try different encodings
            for encoding in ['latin-1', 'utf-8', 'cp1252']:
                try:
                    df = pd.read_csv(filepath, sep='|', encoding=encoding, low_memory=False)
                    print(f"  ✓ Loaded {len(df):,} rows with {encoding} encoding")
                    return df
                except UnicodeDecodeError:
                    continue
            
            # If all fail, try with error handling
            df = pd.read_csv(filepath, sep='|', encoding='latin-1', low_memory=False, on_bad_lines='skip')
            print(f"  ✓ Loaded {len(df):,} rows (with error handling)")
            return df
            
        except Exception as e:
            print(f"  ✗ Error loading file: {e}")
            return pd.DataFrame()
    
    def identify_columns(self, df: pd.DataFrame) -> Dict[str, str]:
        """Identify key columns in the dataframe"""
        
        columns = df.columns.tolist()
        
        # Common column name patterns
        column_map = {
            'municipality': None,
            'year': None,
            'fund': None,
            'department': None,
            'account': None,
            'description': None,
            'amount': None,
            'category': None
        }
        
        # Search for each column type
        for col in columns:
            col_lower = col.lower()
            
            if any(x in col_lower for x in ['unit', 'city', 'town', 'municipality', 'entity']):
                column_map['municipality'] = col
            elif 'year' in col_lower or 'yr' in col_lower:
                column_map['year'] = col
            elif 'fund' in col_lower:
                column_map['fund'] = col
            elif 'dept' in col_lower or 'department' in col_lower:
                column_map['department'] = col
            elif 'accountcode' in col_lower:
                column_map['account'] = col
            elif 'accountdesc' in col_lower or 'accountname' in col_lower:
                column_map['description'] = col
            elif 'desc' in col_lower or ('name' in col_lower and 'account' not in col_lower):
                if not column_map['description']:  # Only if not already set
                    column_map['description'] = col
            elif 'amount' in col_lower or 'total' in col_lower or 'expenditure' in col_lower:
                column_map['amount'] = col
            elif 'category' in col_lower or 'class' in col_lower:
                column_map['category'] = col
        
        print("\n  Column Mapping:")
        for key, value in column_map.items():
            status = "✓" if value else "✗"
            print(f"    {status} {key}: {value}")
        
        return column_map
    
    def extract_benefits_rows(self, df: pd.DataFrame, column_map: Dict) -> pd.DataFrame:
        """Extract rows related to employee benefits"""
        
        if df.empty:
            return df
        
        benefits_mask = pd.Series([False] * len(df))
        
        # Search in description column
        if column_map['description']:
            desc_col = column_map['description']
            for keyword in self.BENEFITS_KEYWORDS:
                benefits_mask |= df[desc_col].astype(str).str.contains(keyword, case=False, na=False)
        
        # Search in account codes
        if column_map['account']:
            acct_col = column_map['account']
            for code in self.BENEFITS_ACCOUNT_CODES:
                benefits_mask |= df[acct_col].astype(str).str.contains(code, na=False)
        
        # Search in category if available
        if column_map['category']:
            cat_col = column_map['category']
            benefits_mask |= df[cat_col].astype(str).str.contains('benefit', case=False, na=False)
        
        benefits_df = df[benefits_mask].copy()
        
        print(f"  Found {len(benefits_df):,} benefits-related rows ({len(benefits_df)/len(df)*100:.1f}%)")
        
        return benefits_df
    
    def aggregate_by_municipality(self, df: pd.DataFrame, column_map: Dict) -> Dict:
        """Aggregate benefits costs by municipality"""
        
        if df.empty or not column_map['municipality'] or not column_map['amount']:
            return {}
        
        muni_col = column_map['municipality']
        amount_col = column_map['amount']
        year_col = column_map['year']
        
        # Convert amount to numeric
        df[amount_col] = pd.to_numeric(df[amount_col], errors='coerce')
        
        # Group by municipality
        grouped = df.groupby([muni_col, year_col] if year_col else [muni_col])
        
        results = {}
        
        for name, group in grouped:
            if isinstance(name, tuple):
                muni_name, year = name
            else:
                muni_name = name
                year = 'Unknown'
            
            total_benefits = group[amount_col].sum()
            
            # Try to extract more details
            breakdown = {}
            if column_map['description']:
                desc_col = column_map['description']
                
                # Health insurance
                health_mask = group[desc_col].astype(str).str.contains('health|medical', case=False, na=False)
                breakdown['health_insurance'] = group[health_mask][amount_col].sum()
                
                # Retirement
                retire_mask = group[desc_col].astype(str).str.contains('PERF|retirement|pension', case=False, na=False)
                breakdown['retirement'] = group[retire_mask][amount_col].sum()
                
                # Dental/Vision
                dental_mask = group[desc_col].astype(str).str.contains('dental|vision', case=False, na=False)
                breakdown['dental_vision'] = group[dental_mask][amount_col].sum()
                
                # Life insurance
                life_mask = group[desc_col].astype(str).str.contains('life insurance', case=False, na=False)
                breakdown['life_insurance'] = group[life_mask][amount_col].sum()
                
                # Other
                breakdown['other'] = total_benefits - sum(breakdown.values())
            
            key = f"{muni_name}_{year}"
            results[key] = {
                'name': muni_name,
                'year': str(year),
                'total_annual_benefits': float(total_benefits),
                'breakdown': {k: float(v) for k, v in breakdown.items() if v > 0}
            }
        
        return results
    
    def enhance_with_employee_counts(self, results: Dict) -> Dict:
        """
        Enhance results with employee count estimates
        
        Methods:
        1. If available in data, use actual counts
        2. Otherwise, use population-based estimates
        3. Or provide ranges based on municipality type
        """
        
        # Population to employee ratio estimates
        # (Cities typically have 8-12 employees per 1,000 residents)
        
        for key, data in results.items():
            # If we don't have employee count, estimate based on typical ranges
            if 'employees' not in data:
                # Estimate based on annual benefits total
                # Typical benefits: $800-1000/employee/month = $9,600-12,000/year
                annual_total = data['total_annual_benefits']
                
                # Conservative estimate: $10,000/employee/year
                estimated_employees = round(annual_total / 10000)
                
                data['estimated_employees'] = estimated_employees
                data['employee_count_method'] = 'estimated_from_benefits_total'
                data['monthly_per_employee_estimate'] = round(annual_total / estimated_employees / 12, 2)
        
        return results
    
    def export_results(self, all_results: Dict, filename: str = "gateway_benchmark_data.json"):
        """Export aggregated results for Mark"""
        
        # Convert to list format
        municipalities = list(all_results.values())
        
        # Sort by total benefits
        municipalities.sort(key=lambda x: x['total_annual_benefits'], reverse=True)
        
        export_data = {
            "source": "Indiana Gateway for Government Units",
            "source_url": "https://gateway.ifionline.org",
            "last_updated": pd.Timestamp.now().strftime("%Y-%m-%d"),
            "data_description": "Actual reported disbursements for employee benefits from Indiana municipalities",
            "total_municipalities": len(municipalities),
            "municipalities": municipalities,
            "methodology": {
                "data_source": "Annual Financial Report - Disbursements by Department",
                "keywords_searched": self.BENEFITS_KEYWORDS,
                "reliability": "HIGH - State-verified actual disbursements",
                "employee_counts": "Estimated from benefits totals where not directly reported"
            },
            "summary_statistics": self.calculate_summary_stats(municipalities)
        }
        
        output_path = self.output_dir / filename
        
        with open(output_path, 'w') as f:
            json.dump(export_data, f, indent=2)
        
        print(f"\n✓ Exported to: {output_path}")
        print(f"  Total municipalities: {len(municipalities)}")
        
        return output_path
    
    def calculate_summary_stats(self, municipalities: List[Dict]) -> Dict:
        """Calculate summary statistics for the dataset"""
        
        if not municipalities:
            return {}
        
        # Extract monthly per employee costs where available
        monthly_costs = [
            m['monthly_per_employee_estimate'] 
            for m in municipalities 
            if 'monthly_per_employee_estimate' in m
        ]
        
        if not monthly_costs:
            return {}
        
        monthly_series = pd.Series(monthly_costs)
        
        return {
            "monthly_per_employee": {
                "min": round(monthly_series.min(), 2),
                "25th_percentile": round(monthly_series.quantile(0.25), 2),
                "median": round(monthly_series.median(), 2),
                "75th_percentile": round(monthly_series.quantile(0.75), 2),
                "90th_percentile": round(monthly_series.quantile(0.90), 2),
                "max": round(monthly_series.max(), 2),
                "mean": round(monthly_series.mean(), 2)
            }
        }
    
    def process_all_files(self):
        """Process all files in the input directory"""
        
        print("\n" + "=" * 70)
        print("INDIANA GATEWAY FILE PARSER")
        print("=" * 70 + "\n")
        
        files = list(self.input_dir.glob("*.txt")) + list(self.input_dir.glob("*.csv"))
        
        if not files:
            print(f"No files found in {self.input_dir}")
            print("\nExpected file patterns:")
            print("  - *.txt (pipe-delimited)")
            print("  - *.csv (pipe-delimited)")
            return None
        
        print(f"Found {len(files)} file(s) to process\n")
        
        all_results = {}
        
        for filepath in files:
            print(f"\n{'─' * 70}")
            print(f"Processing: {filepath.name}")
            print('─' * 70)
            
            df = self.load_file(filepath)
            
            if df.empty:
                continue
            
            print(f"\nDataframe shape: {df.shape}")
            print(f"Columns: {len(df.columns)}")
            
            column_map = self.identify_columns(df)
            
            benefits_df = self.extract_benefits_rows(df, column_map)
            
            if benefits_df.empty:
                print("  ✗ No benefits data found")
                continue
            
            results = self.aggregate_by_municipality(benefits_df, column_map)
            
            print(f"\n  Extracted data for {len(results)} municipality-years")
            
            all_results.update(results)
        
        if not all_results:
            print("\n✗ No benefits data extracted from any files")
            return None
        
        print(f"\n{'=' * 70}")
        print(f"TOTAL EXTRACTED: {len(all_results)} municipality-year combinations")
        print('=' * 70)
        
        # Enhance with estimates
        all_results = self.enhance_with_employee_counts(all_results)
        
        # Export
        output_file = self.export_results(all_results)
        
        return output_file

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Parse Indiana Gateway data files')
    parser.add_argument('--input', default='./gateway_data/raw', help='Input directory with downloaded files')
    parser.add_argument('--output', default='./gateway_data/parsed', help='Output directory for parsed data')
    
    args = parser.parse_args()
    
    parser = GatewayFileParser(args.input, args.output)
    output_file = parser.process_all_files()
    
    if output_file:
        print("\n" + "=" * 70)
        print("SUCCESS! Data ready for Mark integration")
        print("=" * 70)
        print(f"\nNext steps:")
        print(f"1. Review the output file: {output_file}")
        print(f"2. Feed this data into Mark's system prompt")
        print(f"3. Update Mark's benchmarking logic to reference real data")
        print(f"4. Test Mark with queries like:")
        print(f"   - 'What do other cities our size pay?'")
        print(f"   - 'How does $1,050/month compare to benchmarks?'")
    
if __name__ == "__main__":
    main()
