#!/usr/bin/env python3
"""
Indiana Gateway Automated Downloader

Uses Selenium to automatically download data files from Indiana Gateway
by submitting the download forms programmatically.

Requirements:
    pip install selenium webdriver-manager --break-system-packages
    
Usage:
    python gateway_auto_downloader.py --headless --output ./gateway_data/raw
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from pathlib import Path
import time
import os

class GatewayAutoDownloader:
    """Automated downloader for Indiana Gateway data"""
    
    URL = "https://gateway.ifionline.org/public/download.aspx"
    
    # Download configurations
    DOWNLOADS = [
        {
            "data_set": "Annual Financial Reports",
            "file": "Disbursements by Fund and Department",
            "unit_type": "City/Town",
            "year": "2024"
        },
        {
            "data_set": "Annual Financial Reports",
            "file": "Disbursements by Fund and Department",
            "unit_type": "City/Town",
            "year": "2023"
        },
        {
            "data_set": "Annual Financial Reports",
            "file": "Disbursements by Fund and Department",
            "unit_type": "City/Town",
            "year": "2022"
        },
        {
            "data_set": "Annual Financial Reports",
            "file": "Disbursements by Fund and Department",
            "unit_type": "County",
            "year": "2024"
        },
        {
            "data_set": "Annual Financial Reports",
            "file": "Disbursements by Fund",
            "unit_type": "City/Town",
            "year": "2024"
        }
    ]
    
    def __init__(self, download_dir: Path, headless: bool = True):
        self.download_dir = Path(download_dir)
        self.download_dir.mkdir(parents=True, exist_ok=True)
        
        # Setup Chrome options
        chrome_options = Options()
        
        if headless:
            chrome_options.add_argument("--headless=new")
        
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--window-size=1920,1080")
        
        # Set download directory
        prefs = {
            "download.default_directory": str(self.download_dir.absolute()),
            "download.prompt_for_download": False,
            "download.directory_upgrade": True,
            "safebrowsing.enabled": True
        }
        chrome_options.add_experimental_option("prefs", prefs)
        
        # Initialize driver
        service = Service(ChromeDriverManager().install())
        self.driver = webdriver.Chrome(service=service, options=chrome_options)
        self.wait = WebDriverWait(self.driver, 10)
        
        print(f"✓ Chrome driver initialized")
        print(f"✓ Download directory: {self.download_dir.absolute()}")
    
    def download_file(self, config: dict) -> bool:
        """Download a single file based on configuration"""
        
        print(f"\n{'─' * 70}")
        print(f"Downloading: {config['file']}")
        print(f"  Data Set: {config['data_set']}")
        print(f"  Unit Type: {config['unit_type']}")
        print(f"  Year: {config['year']}")
        print('─' * 70)
        
        try:
            # Navigate to download page
            self.driver.get(self.URL)
            time.sleep(2)
            
            # Wait for page to load
            self.wait.until(EC.presence_of_element_located((By.TAG_NAME, "select")))
            
            # Find and select Data Set dropdown
            # Note: The actual element IDs/names would need to be inspected from the page
            # This is a template that would need to be adjusted based on the actual form
            
            try:
                # Try to find data set dropdown
                data_set_select = Select(self.driver.find_element(By.ID, "ctl00_ContentPlaceHolder1_ddlDataSet"))
                data_set_select.select_by_visible_text(config['data_set'])
                time.sleep(1)
                print("  ✓ Selected data set")
            except Exception as e:
                print(f"  ✗ Could not select data set: {e}")
                return False
            
            try:
                # Select file type
                file_select = Select(self.driver.find_element(By.ID, "ctl00_ContentPlaceHolder1_ddlFile"))
                file_select.select_by_visible_text(config['file'])
                time.sleep(1)
                print("  ✓ Selected file type")
            except Exception as e:
                print(f"  ✗ Could not select file type: {e}")
                return False
            
            try:
                # Select unit type
                unit_select = Select(self.driver.find_element(By.ID, "ctl00_ContentPlaceHolder1_ddlUnitType"))
                unit_select.select_by_visible_text(config['unit_type'])
                time.sleep(1)
                print("  ✓ Selected unit type")
            except Exception as e:
                print(f"  ✗ Could not select unit type: {e}")
                return False
            
            try:
                # Select year
                year_select = Select(self.driver.find_element(By.ID, "ctl00_ContentPlaceHolder1_ddlYear"))
                year_select.select_by_visible_text(config['year'])
                time.sleep(1)
                print("  ✓ Selected year")
            except Exception as e:
                print(f"  ✗ Could not select year: {e}")
                return False
            
            # Find and click download button
            try:
                download_button = self.driver.find_element(By.ID, "ctl00_ContentPlaceHolder1_btnDownload")
                download_button.click()
                print("  ✓ Clicked download button")
                
                # Wait for download to complete
                time.sleep(5)
                
                # Check if file was downloaded
                files = list(self.download_dir.glob("*"))
                if files:
                    latest_file = max(files, key=os.path.getctime)
                    print(f"  ✓ Downloaded: {latest_file.name}")
                    return True
                else:
                    print("  ✗ No file downloaded")
                    return False
                    
            except Exception as e:
                print(f"  ✗ Could not click download button: {e}")
                return False
        
        except Exception as e:
            print(f"  ✗ Error during download: {e}")
            return False
    
    def download_all(self):
        """Download all configured files"""
        
        print("\n" + "=" * 70)
        print("INDIANA GATEWAY AUTOMATED DOWNLOADER")
        print("=" * 70)
        
        successful = 0
        failed = 0
        
        for config in self.DOWNLOADS:
            if self.download_file(config):
                successful += 1
            else:
                failed += 1
            
            time.sleep(2)  # Be respectful to the server
        
        print("\n" + "=" * 70)
        print("DOWNLOAD SUMMARY")
        print("=" * 70)
        print(f"Successful: {successful}")
        print(f"Failed: {failed}")
        print(f"Total files in directory: {len(list(self.download_dir.glob('*')))}")
        
        self.driver.quit()
    
    def inspect_page(self):
        """Helper method to inspect the page structure"""
        
        print("\n" + "=" * 70)
        print("PAGE INSPECTION MODE")
        print("=" * 70)
        
        self.driver.get(self.URL)
        time.sleep(2)
        
        # Find all select elements
        selects = self.driver.find_elements(By.TAG_NAME, "select")
        
        print(f"\nFound {len(selects)} dropdown elements:\n")
        
        for i, select in enumerate(selects, 1):
            try:
                elem_id = select.get_attribute("id")
                elem_name = select.get_attribute("name")
                
                print(f"{i}. ID: {elem_id}")
                print(f"   Name: {elem_name}")
                
                # Get options
                select_obj = Select(select)
                options = [opt.text for opt in select_obj.options]
                print(f"   Options: {options[:5]}{'...' if len(options) > 5 else ''}")
                print()
            except Exception as e:
                print(f"   Error reading select: {e}\n")
        
        # Find download button
        buttons = self.driver.find_elements(By.TAG_NAME, "button")
        inputs = self.driver.find_elements(By.XPATH, "//input[@type='submit' or @type='button']")
        
        print(f"Found {len(buttons)} buttons and {len(inputs)} input buttons:\n")
        
        for btn in buttons + inputs:
            try:
                btn_id = btn.get_attribute("id")
                btn_text = btn.text or btn.get_attribute("value")
                print(f"  - ID: {btn_id}, Text: {btn_text}")
            except:
                pass
        
        input("\nPress Enter to close browser...")
        self.driver.quit()

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Auto-download Indiana Gateway data')
    parser.add_argument('--output', default='./gateway_data/raw', help='Output directory')
    parser.add_argument('--headless', action='store_true', help='Run in headless mode')
    parser.add_argument('--inspect', action='store_true', help='Inspect page structure')
    
    args = parser.parse_args()
    
    downloader = GatewayAutoDownloader(args.output, headless=args.headless)
    
    if args.inspect:
        downloader.inspect_page()
    else:
        downloader.download_all()

if __name__ == "__main__":
    main()
