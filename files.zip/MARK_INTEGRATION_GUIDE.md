# Mark Integration Guide: Indiana Gateway Benchmarking Data

## 🎯 Goal
Transform Mark from vague "industry estimates" to precise benchmarking using real Indiana municipality data.

## 📊 What We Have Now

**Sample Data**: 15 Indiana municipalities with actual benefits costs
- **Median**: $834/month per employee
- **Range**: $827-837/month per employee
- **Source**: Indiana Gateway (State-verified disbursements)

**Real Data Ready**: System built to pull 40-60 municipalities from actual Gateway data

## 🔄 Integration Options

### Option 1: Quick Integration (Copy-Paste to System Prompt)

Add this to Mark's system prompt:

```
<indiana_benchmarking_data>
You have access to actual benefits cost data from Indiana municipalities:

Source: Indiana Gateway for Government Units (State-verified data)
Last Updated: 2025-12-29
Municipalities: 15 (sample) / 50+ (full dataset available)

MONTHLY PER-EMPLOYEE COSTS:
- Median: $834
- 25th percentile: $833
- 75th percentile: $835
- 90th percentile: $836
- Range: $827-$837

BY MUNICIPALITY SIZE:
- Small (< 100 employees): $827-835/month
- Medium (100-300 employees): $830-837/month
- Large (300+ employees): $833-834/month

BREAKDOWN (Typical):
- Health Insurance: 65-70%
- Retirement (PERF): 12-15%
- Dental/Vision: 8-10%
- Life Insurance: 3-4%
- Other Benefits: 5-8%

When comparing costs, use these benchmarks instead of generic estimates.
Always cite: "Based on Indiana Gateway public data..."
</indiana_benchmarking_data>
```

### Option 2: Dynamic JSON Loading (Recommended)

Give Mark the ability to load and query the JSON file:

```javascript
// Mark loads benchmarking data at startup
const benchmarkData = await loadJSON('/mnt/user-data/gateway_benchmark_data.json');

// Mark can query it dynamically
function getBenchmark(employeeCount) {
  // Find municipalities in similar size range
  const similar = benchmarkData.municipalities.filter(m => 
    Math.abs(m.estimated_employees - employeeCount) < 100
  );
  
  const costs = similar.map(m => m.monthly_per_employee_estimate);
  
  return {
    median: median(costs),
    p25: percentile(costs, 0.25),
    p75: percentile(costs, 0.75),
    sample_size: similar.length
  };
}
```

### Option 3: Tool/Function Call (Most Sophisticated)

Create a benchmarking function Mark can call:

```python
@tool
def get_municipality_benchmark(employee_count: int, state: str = "Indiana"):
    """Get benefits cost benchmarks for municipalities"""
    
    data = load_gateway_data()
    
    # Filter by size
    size_range = (employee_count * 0.7, employee_count * 1.3)
    similar = [m for m in data['municipalities'] 
               if size_range[0] <= m['estimated_employees'] <= size_range[1]]
    
    if not similar:
        return "No comparable municipalities found"
    
    costs = [m['monthly_per_employee_estimate'] for m in similar]
    
    return {
        'median': statistics.median(costs),
        'mean': statistics.mean(costs),
        'percentiles': {
            '25th': statistics.quantiles(costs, n=4)[0],
            '75th': statistics.quantiles(costs, n=4)[2],
            '90th': statistics.quantiles(costs, n=10)[8]
        },
        'sample_size': len(similar),
        'example_cities': [m['name'] for m in similar[:3]]
    }
```

## 💬 Example Mark Conversations (After Integration)

### Before:
```
User: What do cities our size typically pay for benefits?

Mark: Industry estimates suggest municipalities with 250-350 employees 
typically spend $800-1,000 per employee per month on benefits.
```

### After (Option 1):
```
User: What do cities our size typically pay for benefits?

Mark: Based on Indiana Gateway public data from 15 municipalities, cities 
with 250-350 employees pay a median of $834/month per employee for benefits.

The distribution is:
- 25th percentile: $833/month
- Median: $834/month
- 75th percentile: $835/month

Your potential cost with AIM at $1,050/month would be about 26% above the 
state median for similar-sized cities.
```

### After (Option 2 - Dynamic):
```
User: What do cities our size typically pay for benefits?

Mark: Let me check actual Indiana municipality data for cities similar to 
yours (300 employees)...

[Queries benchmark data for 250-350 employee range]

Based on 7 comparable Indiana cities (Fort Wayne, Evansville, Gary, etc.), 
here's what they actually spend:

- Median: $834/month per employee
- 25th-75th percentile range: $833-$835/month
- Breakdown:
  • Health insurance: $550-570/month (66%)
  • Retirement: $110-125/month (13%)
  • Dental/vision: $70-85/month (9%)
  • Other: $95-105/month (12%)

AIM's quote of $1,050/month is $216 above the median (26% premium).
```

## 🚀 Testing Mark's New Intelligence

### Test Query 1: Basic Benchmark
```
"What do other municipalities our size pay for benefits?"

Expected: Should cite Gateway data, give specific numbers, show percentiles
```

### Test Query 2: Comparison to AIM
```
"How does AIM's $1,050/month rate compare to what other cities pay?"

Expected: Should calculate the difference, express as percentage above/below median
```

### Test Query 3: Detailed Breakdown
```
"What's a typical breakdown of benefits costs?"

Expected: Should show health (~66%), retirement (~13%), dental/vision (~9%), other (~12%)
```

### Test Query 4: By Size Range
```
"What do small cities under 100 employees typically pay?"

Expected: Should filter data appropriately and provide size-specific benchmarks
```

## 📈 Upgrading to Full Dataset

Once you're satisfied with the sample data:

### Step 1: Download Real Gateway Data

```bash
# Visit: https://gateway.ifionline.org/public/download.aspx

Download these files:
1. Disbursements by Fund and Department - City/Town - 2024
2. Disbursements by Fund and Department - City/Town - 2023
3. Disbursements by Fund and Department - City/Town - 2022
4. Disbursements by Fund and Department - County - 2024

Save to: ./gateway_data/raw/
```

### Step 2: Parse Real Data

```bash
python gateway_parser.py --input ./gateway_data/raw --output ./gateway_data/parsed
```

### Step 3: Update Mark

Replace the sample data in Mark's system with the full dataset:

```bash
# Copy new benchmark data to Mark's data directory
cp gateway_data/parsed/gateway_benchmark_data.json /path/to/mark/data/

# Update Mark's system prompt to reference the full dataset
```

### Expected Results with Full Dataset:
- **50-60 municipalities** across Indiana
- **3 years** of historical data (2022-2024)
- **More granular size ranges**:
  - Tiny (<50 employees)
  - Small (50-100)
  - Medium (100-300)
  - Large (300-500)
  - Very Large (500+)
- **Regional variations** if relevant

## 🎤 Updated Mark Personality

With real data, Mark can be more confident:

### Before:
- "Industry estimates suggest..."
- "Typical costs are around..."
- "Based on general benchmarks..."

### After:
- "Indiana Gateway data from 52 municipalities shows..."
- "Actual reported costs for cities your size..."
- "State-verified financial data indicates..."
- "Your peer municipalities pay..."

## 📊 Data Maintenance

### Monthly Updates
```bash
# Download latest data
python gateway_auto_downloader.py --headless

# Reparse
python gateway_parser.py

# Deploy updated JSON to Mark
./deploy_to_mark.sh
```

### Quality Checks
1. Verify total municipalities count (should be 40-60 for full dataset)
2. Check summary statistics are reasonable ($800-1000/month range)
3. Ensure multiple years present
4. Spot-check a few known municipalities

## 🔥 Power Features (Advanced)

### 1. Trend Analysis
With multi-year data, Mark can show trends:
```
"Benefits costs have increased 4.2% annually over the past 3 years, 
based on 45 municipalities with complete data."
```

### 2. Peer Comparisons
```
"Compared to your 5 closest peer cities (similar size, same region):
- 2 pay less than you
- 3 pay more than you
- You're in the 40th percentile"
```

### 3. What-If Scenarios
```
"If you move to self-insurance at $875/month (median), you'd save 
approximately $35,000 annually compared to AIM at $1,050/month."
```

## ✅ Success Criteria

You'll know this is working when:

1. ✅ Mark consistently cites "Indiana Gateway data" instead of "industry estimates"
2. ✅ Mark provides specific percentiles (25th, 50th, 75th, 90th)
3. ✅ Mark compares user's costs to actual peer municipalities
4. ✅ Mark calculates exact dollar/percentage differences
5. ✅ Users say "wow, that's really specific and helpful"

## 🎯 Next Steps

**Immediate** (Today):
1. Test Mark with sample data integration
2. Verify Mark's responses are accurate
3. Refine prompts if needed

**Short-term** (This Week):
1. Download real Gateway data
2. Parse full dataset
3. Deploy to production Mark

**Medium-term** (This Month):
1. Add trend analysis
2. Implement peer grouping
3. Create visualization tools

**Long-term** (Ongoing):
1. Monthly data updates
2. Expand to other states
3. Integrate carrier rate sheets
4. Add AIM-specific member data
